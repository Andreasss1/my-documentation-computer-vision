#include <TinyGPS++.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <time.h>

const char* ssid = "nama-wifi";
const char* password = "pw-wifi";

const char* mqtt_broker = "broker.emqx.io";
const int mqtt_port = 1883;
const char* mqtt_topic_data = "gps/tracker/data";
const char* mqtt_topic_relay1 = "gps/tracker/relay1";
const char* mqtt_topic_relay1_status = "gps/tracker/relay1/status";
const char* mqtt_topic_relay2 = "gps/tracker/relay2";
const char* mqtt_topic_relay2_status = "gps/tracker/relay2/status";
const char* mqtt_topic_sos = "gps/tracker/sos";
const char* mqtt_client_id = "ESP32_GPS_Tracker";

#define RXD2 16
#define TXD2 17
#define GPS_BAUD 9600

#define RELAY1_PIN 18
#define RELAY2_PIN 2
#define BUTTON_PIN 19

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define SDA_PIN 21
#define SCL_PIN 22
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

const char* ntpServer = "pool.ntp.org";
const long gmtOffset_sec = 7 * 3600;
const int daylightOffset_sec = 0;

TinyGPSPlus gps;

HardwareSerial gpsSerial(2);
WiFiClient espClient;
PubSubClient client(espClient);

unsigned long lastMQTTSend = 0;
const unsigned long mqttInterval = 5000;
unsigned long lastDisplayUpdate = 0;
const unsigned long displayInterval = 1000;
bool relay1State = false;
bool relay2State = false;

// Simple button variables for single press SOS
bool lastButtonState = HIGH;
unsigned long lastDebounceTime = 0;
unsigned long debounceDelay = 50;

void setup() {
  Serial.begin(115200);
  
  // Initialize relays
  pinMode(RELAY1_PIN, OUTPUT);
  pinMode(RELAY2_PIN, OUTPUT);
  digitalWrite(RELAY1_PIN, LOW);
  digitalWrite(RELAY2_PIN, LOW);
  Serial.println("Relay 1 initialized on GPIO18");
  Serial.println("Relay 2 initialized on GPIO2");
  
  // Initialize push button for SOS emergency
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  Serial.println("SOS emergency button initialized on GPIO19");
  
  Wire.begin(SDA_PIN, SCL_PIN);
  
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("SSD1306 allocation failed"));
    for(;;);
  }
  
  display.clearDisplay();
  display.setTextColor(WHITE);
  display.setCursor(0, 0);
  display.println("GPS Tracker Init...");
  display.display();
  
  gpsSerial.begin(GPS_BAUD, SERIAL_8N1, RXD2, TXD2);
  Serial.println("GPS Serial started at 9600 baud rate");
  
  setup_wifi();
  
  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
  
  client.setServer(mqtt_broker, mqtt_port);
  client.setCallback(callback);
  
  Serial.println("Setup complete!");
}

void setup_wifi() {
  delay(10);
  Serial.println();
  Serial.print("Connecting to ");
  Serial.println(ssid);

  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("Connecting WiFi...");
  display.display();

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi connected");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
  
  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("WiFi Connected!");
  display.println("Getting time...");
  display.display();
  delay(2000);
}

void callback(char* topic, byte* payload, unsigned int length) {
  String message;
  for (int i = 0; i < length; i++) {
    message += (char)payload[i];
  }
  
  Serial.print("Message arrived [");
  Serial.print(topic);
  Serial.print("] ");
  Serial.println(message);
  
  // Handle Relay 1 commands
  if (String(topic) == mqtt_topic_relay1) {
    if (message == "ON" || message == "1") {
      relay1State = true;
      digitalWrite(RELAY1_PIN, HIGH);
      Serial.println("Relay 1 turned ON");
      sendRelay1Status();
    } else if (message == "OFF" || message == "0") {
      relay1State = false;
      digitalWrite(RELAY1_PIN, LOW);
      Serial.println("Relay 1 turned OFF");
      sendRelay1Status();
    }
  }
  
  // Handle Relay 2 commands
  if (String(topic) == mqtt_topic_relay2) {
    if (message == "ON" || message == "1") {
      relay2State = true;
      digitalWrite(RELAY2_PIN, HIGH);
      Serial.println("Relay 2 turned ON");
      sendRelay2Status();
    } else if (message == "OFF" || message == "0") {
      relay2State = false;
      digitalWrite(RELAY2_PIN, LOW);
      Serial.println("Relay 2 turned OFF");
      sendRelay2Status();
    }
  }
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    
    if (client.connect(mqtt_client_id)) {
      Serial.println("connected");
      
      client.subscribe(mqtt_topic_relay1);
      client.subscribe(mqtt_topic_relay2);
      Serial.print("Subscribed to relay control topics: ");
      Serial.print(mqtt_topic_relay1);
      Serial.print(" and ");
      Serial.println(mqtt_topic_relay2);
      
      sendRelay1Status();
      sendRelay2Status();
      
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      delay(5000);
    }
  }
}

void sendRelay1Status() {
  StaticJsonDocument<100> doc;
  doc["relay_state"] = relay1State;
  doc["relay_id"] = 1;
  doc["device_id"] = mqtt_client_id;
  doc["timestamp"] = millis();
  
  String jsonString;
  serializeJson(doc, jsonString);
  
  if (client.publish(mqtt_topic_relay1_status, jsonString.c_str())) {
    Serial.println("Relay 1 status sent:");
    Serial.println(jsonString);
  }
}

void sendRelay2Status() {
  StaticJsonDocument<100> doc;
  doc["relay_state"] = relay2State;
  doc["relay_id"] = 2;
  doc["device_id"] = mqtt_client_id;
  doc["timestamp"] = millis();
  
  String jsonString;
  serializeJson(doc, jsonString);
  
  if (client.publish(mqtt_topic_relay2_status, jsonString.c_str())) {
    Serial.println("Relay 2 status sent:");
    Serial.println(jsonString);
  }
}

void sendSOSAlert() {
  StaticJsonDocument<400> doc;
  doc["device_id"] = mqtt_client_id;
  doc["timestamp"] = millis();
  doc["alert_type"] = "SOS";
  doc["priority"] = "CRITICAL";
  doc["message"] = "SOS EMERGENCY - Emergency button pressed!";
  
  // Add GPS location if available
  if (gps.location.isValid()) {
    doc["latitude"] = gps.location.lat();
    doc["longitude"] = gps.location.lng();
    doc["altitude"] = gps.altitude.meters();
    doc["speed_kmh"] = gps.speed.kmph();
  } else {
    doc["latitude"] = "N/A";
    doc["longitude"] = "N/A";
    doc["message"] = "SOS EMERGENCY - GPS location not available!";
  }
  
  // Add GPS time if available
  if (gps.date.isValid() && gps.time.isValid()) {
    char datetime[30];
    sprintf(datetime, "%04d-%02d-%02d %02d:%02d:%02d", 
            gps.date.year(), gps.date.month(), gps.date.day(),
            gps.time.hour(), gps.time.minute(), gps.time.second());
    doc["datetime"] = datetime;
  }
  
  String jsonString;
  serializeJson(doc, jsonString);
  
  // Send only to SOS topic
  if (client.publish(mqtt_topic_sos, jsonString.c_str())) {
    Serial.println("SOS alert sent successfully:");
    Serial.println(jsonString);
  } else {
    Serial.println("Failed to send SOS alert via MQTT");
  }
  
  // Visual feedback - blink SOS on display
  showSOSFeedback();
}

void showSOSFeedback() {
  for(int i = 0; i < 6; i++) {
    display.clearDisplay();
    display.setTextSize(3);
    display.setCursor(20, 15);
    display.println("SOS!");
    display.setTextSize(1);
    display.setCursor(15, 45);
    display.println("Emergency Alert Sent");
    display.display();
    delay(300);
    
    display.clearDisplay();
    display.display();
    delay(200);
  }
}

void handleButton() {
  int reading = digitalRead(BUTTON_PIN);
  
  // Debounce logic
  if (reading != lastButtonState) {
    lastDebounceTime = millis();
  }
  
  if ((millis() - lastDebounceTime) > debounceDelay) {
    // Button pressed (LOW because of INPUT_PULLUP) - Single press SOS
    if (reading == LOW && lastButtonState == HIGH) {
      Serial.println("SOS BUTTON PRESSED - SENDING EMERGENCY ALERT!");
      sendSOSAlert();
    }
  }
  
  lastButtonState = reading;
}

void sendGPSData() {
  if (gps.location.isValid()) {
    StaticJsonDocument<400> doc;
    
    doc["device_id"] = mqtt_client_id;
    doc["timestamp"] = millis();
    doc["latitude"] = gps.location.lat();
    doc["longitude"] = gps.location.lng();
    doc["altitude"] = gps.altitude.meters();
    doc["speed_kmh"] = gps.speed.kmph();
    doc["hdop"] = gps.hdop.value() / 100.0;
    doc["satellites"] = gps.satellites.value();
    doc["relay1_state"] = relay1State;
    doc["relay2_state"] = relay2State;
    doc["button_state"] = digitalRead(BUTTON_PIN) ? "RELEASED" : "PRESSED";
    
    if (gps.date.isValid() && gps.time.isValid()) {
      char datetime[30];
      sprintf(datetime, "%04d-%02d-%02d %02d:%02d:%02d", 
              gps.date.year(), gps.date.month(), gps.date.day(),
              gps.time.hour(), gps.time.minute(), gps.time.second());
      doc["datetime"] = datetime;
    }
    
    String jsonString;
    serializeJson(doc, jsonString);
    
    if (client.publish(mqtt_topic_data, jsonString.c_str())) {
      Serial.println("GPS data sent via MQTT:");
      Serial.println(jsonString);
    } else {
      Serial.println("Failed to send GPS data via MQTT");
    }
  }
}

void drawBatteryIcon() {
  int battX = 108;
  int battY = 2;
  
  display.drawRect(battX, battY, 16, 8, WHITE);
  display.drawRect(battX + 16, battY + 2, 2, 4, WHITE);
  
  int battLevel = 3;
  for(int i = 0; i < battLevel; i++) {
    display.fillRect(battX + 2 + (i * 3), battY + 2, 2, 4, WHITE);
  }
  
  display.setTextSize(1);
  display.setCursor(85, 4);
  display.print("85%");
}

void drawButtonStatus() {
  // Display button status in top left corner
  display.setTextSize(1);
  display.setCursor(0, 0);
  if (digitalRead(BUTTON_PIN) == LOW) {
    display.print("SOS!");
  } else {
    display.print("   ");
  }
}

void drawRelayStatus() {
  // Display relay status below battery
  display.setTextSize(1);
  display.setCursor(70, 15);
  display.print("R1:");
  display.print(relay1State ? "ON" : "OFF");
  display.setCursor(70, 25);
  display.print("R2:");
  display.print(relay2State ? "ON" : "OFF");
}

void displayTime() {
  struct tm timeinfo;
  if(!getLocalTime(&timeinfo)){
    display.setTextSize(1);
    display.setCursor(10, 15);
    display.println("Failed to get time");
    return;
  }
  
  char timeString[9];
  strftime(timeString, sizeof(timeString), "%H:%M:%S", &timeinfo);
  
  display.setTextSize(2);
  display.setCursor(0, 35);
  display.println(timeString);
}

void displaySuncuffs() {
  display.setTextSize(1);
  display.setCursor(38, 56);
  display.println("suncuffs");
}

void updateDisplay() {
  display.clearDisplay();
  drawButtonStatus();
  drawBatteryIcon();
  drawRelayStatus();
  displayTime();
  displaySuncuffs();
  display.display();
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    setup_wifi();
  }
  
  if (!client.connected()) {
    reconnect();
  }
  client.loop();
  
  // Handle button input
  handleButton();
  
  while (gpsSerial.available() > 0) {
    if (gps.encode(gpsSerial.read())) {
      if (gps.location.isUpdated()) {
        Serial.print("LAT: ");
        Serial.println(gps.location.lat(), 6);
        Serial.print("LONG: "); 
        Serial.println(gps.location.lng(), 6);
        Serial.print("SPEED (km/h) = "); 
        Serial.println(gps.speed.kmph()); 
        Serial.print("ALT (m) = "); 
        Serial.println(gps.altitude.meters());
        Serial.print("HDOP = "); 
        Serial.println(gps.hdop.value() / 100.0); 
        Serial.print("Satellites = "); 
        Serial.println(gps.satellites.value());
        Serial.print("Relay 1 State = "); 
        Serial.println(relay1State ? "ON" : "OFF");
        Serial.print("Relay 2 State = "); 
        Serial.println(relay2State ? "ON" : "OFF");
        Serial.print("Button State = ");
        Serial.println(digitalRead(BUTTON_PIN) ? "RELEASED" : "PRESSED");
        Serial.println("");
      }
    }
  }
  
  if (millis() - lastMQTTSend >= mqttInterval) {
    sendGPSData();
    lastMQTTSend = millis();
  }
  
  if (millis() - lastDisplayUpdate >= displayInterval) {
    updateDisplay();
    lastDisplayUpdate = millis();
  }
}